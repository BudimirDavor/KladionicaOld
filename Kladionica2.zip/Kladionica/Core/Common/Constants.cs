﻿namespace Kladionica.Core
{
    public static class Constants
    {
        public readonly static string AppName = "Kladionica";
        public readonly static int MaxNumOfOkladasPerListic = 25;
        public readonly static double MaxSumOfDobitakOnIdenticalListic = 1000;
    }
}