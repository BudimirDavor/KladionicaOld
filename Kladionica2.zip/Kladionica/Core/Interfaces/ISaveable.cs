﻿namespace Kladionica.Core
{
    public interface ISaveable
    {
        void Save();
    }
}
