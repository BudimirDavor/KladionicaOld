﻿namespace Kladionica.Core
{
    public static class Constants
    {
        public readonly static string AppName = "Kladionica";
    }
}