﻿namespace Kladionica.Core.UIModel
{
    public class Oklada
    {
        public long OkladaId { get; set; }
        public long ListicId { get; set; }
        public long PonudaId { get; set; }
        public double Koeficient { get; set; }
        public string Listic { get; set; }
        public string Ponuda { get; set; }
    }
}