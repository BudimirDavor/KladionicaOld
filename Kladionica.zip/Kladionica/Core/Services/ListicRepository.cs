﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Kladionica.Core
{
    public class ListicRepository : DatabaseRepository, IListicRepository
    {
        public IEnumerable<UIModel.Listic> GetListics(string vrijemeUplate, string iznosUplate)
        {
            DateTime.TryParse(vrijemeUplate, out DateTime vrijeme);
            double.TryParse(iznosUplate, out double iznos);

            var query = _dataContext.Listics
                .Where(r => (string.IsNullOrEmpty(vrijemeUplate) || r.VrijemeUplate == vrijeme)
                    && (string.IsNullOrEmpty(iznosUplate) || r.IznosUplate == iznos));

            return query.Select(ListicFactory.Create);
        }

        public UIModel.Listic GetListic(long listicId)
        {
            var record = Find(listicId);

            if (record != null)
            {
                return ListicFactory.Create(record);
            }

            throw new Exception($"Found no Listic record with ListicId={listicId}");
        }

        public void Add(UIModel.Listic listic)
        {
            var record = ListicFactory.CreateRecord(listic);

            _dataContext.Listics.Add(record);
        }

        public void Update(UIModel.Listic listic)
        {
            var record = Find(listic.ListicId);

            if (record != null)
            {
                record.VrijemeUplate = listic.VrijemeUplate;
                record.IznosUplate = listic.IznosUplate;
                record.MoguciDobitak = listic.MoguciDobitak;
            }
        }

        public void Delete(long listicId)
        {
            var record = Find(listicId);

            if (record != null)
            {
                _dataContext.Listics.Remove(record);
            }
        }

        private Model.Listic Find(long listicId)
        {
            return _dataContext.Listics.Find(listicId);
        }
    }
}
